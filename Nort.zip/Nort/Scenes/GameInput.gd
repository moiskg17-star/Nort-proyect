extends Node

func _ready():
	print("✅ GameInput activo")

func _input(event):

	# DEBUG BASE (para confirmar que el nodo recibe input)
	# Si esto NO imprime, el nodo no está en escena o no se ejecuta
	#print("INPUT:", event)

	# =========================
	# TOUCH START / END
	# =========================

	if event is InputEventScreenTouch:

		# TOUCH PRESSED
		if event.pressed:

			# IZQUIERDA → MOVIMIENTO
			if event.position.x < get_viewport().size.x * 0.5 and InputManager.move_touch_id == -1:
				InputManager.move_touch_id = event.index

			# DERECHA → CÁMARA
			elif event.position.x >= get_viewport().size.x * 0.5 and InputManager.camera_touch_id == -1:
				InputManager.camera_touch_id = event.index

		# TOUCH RELEASED
		else:

			if event.index == InputManager.move_touch_id:
				InputManager.clear_move()

			if event.index == InputManager.camera_touch_id:
				InputManager.clear_camera()


	# =========================
	# DRAG
	# =========================

	elif event is InputEventScreenDrag:

		# -------------------------
		# MOVIMIENTO (IZQUIERDA)
		# -------------------------

		if event.index == InputManager.move_touch_id:

			var delta = event.relative

			# deadzone ya está en joystick, aquí solo normalizamos
			InputManager.set_move_input(delta.limit_length(1.0))


		# -------------------------
		# CÁMARA (DERECHA)
		# -------------------------

		elif event.index == InputManager.camera_touch_id:

			InputManager.set_camera_input(event.relative)
