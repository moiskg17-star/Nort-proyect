extends Node3D

@export var sensitivity := 3.0

# 🔥 suavizado tipo FPS (opcional pero recomendado)
@export var smooth_speed := 12.0

var target_rotation := Vector2.ZERO
var current_rotation := Vector2.ZERO


func _ready():
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)


func _process(delta):

	# =========================
	# 🔥 INPUT (ejemplo típico)
	# =========================
	var look_input = InputManager.look_input

	# acumulamos intención
	target_rotation.x += look_input.y * sensitivity * delta
	target_rotation.y += look_input.x * sensitivity * delta

	# =========================
	# 🔥 LIMITES (evita volcar cámara)
	# =========================
	target_rotation.x = clamp(target_rotation.x, deg_to_rad(-80), deg_to_rad(80))

	# =========================
	# 🔥 SUAVIZADO (delta activo aquí también)
	# =========================
	current_rotation.x = lerp(current_rotation.x, target_rotation.x, smooth_speed * delta)
	current_rotation.y = lerp(current_rotation.y, target_rotation.y, smooth_speed * delta)

	rotation.x = current_rotation.x
	rotation.y = current_rotation.y