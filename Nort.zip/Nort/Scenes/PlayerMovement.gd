extends CharacterBody2D

@export var max_speed := 6.0

# 🔥 aceleración base
@export var acceleration := 18.0

# 🔥 fricción al soltar input
@export var friction := 14.0

# 🔥 curva de aceleración (NO LINEAL)
# >1 = arranque suave, más control fino
@export var accel_curve := 1.7

# 🔥 opcional: suaviza dirección (sensación más "peso")
@export var direction_smooth := 12.0


var smoothed_dir := Vector2.ZERO


func _physics_process(delta):

	var input_dir = InputManager.move_input

	# 🔥 magnitud del input (0–1)
	var input_strength = clamp(input_dir.length(), 0.0, 1.0)

	# 🔥 dirección limpia
	var target_dir = Vector2.ZERO

	if input_strength > 0.001:
		target_dir = input_dir.normalized()

		# 🔥 suavizado de dirección (sensación física)
		smoothed_dir = smoothed_dir.lerp(target_dir, direction_smooth * delta)
	else:
		smoothed_dir = smoothed_dir.lerp(Vector2.ZERO, direction_smooth * delta)


	# =========================
	# 🔥 CURVA DE ACELERACIÓN
	# =========================

	if input_strength > 0.001:

		# curva no lineal (control fino en centro)
		var curved_strength = pow(input_strength, accel_curve)

		# velocidad objetivo
		var target_velocity = smoothed_dir * max_speed * curved_strength

		# aceleración progresiva hacia objetivo
		velocity = velocity.move_toward(
			target_velocity,
			acceleration * delta
		)

	else:

		# =========================
		# 🔥 FRICTION NATURAL
		# =========================

		velocity = velocity.move_toward(
			Vector2.ZERO,
			friction * delta
		)


	move_and_slide()
