extends Node

# ==========================
# MOVIMIENTO
# ==========================

var move_input: Vector2 = Vector2.ZERO
var camera_input: Vector2 = Vector2.ZERO

# ==========================
# TOUCH IDS (multitouch estable)
# ==========================

var move_touch_id := -1
var camera_touch_id := -1


# ==========================
# SETTERS SEGUROS
# ==========================

func set_move_input(value: Vector2) -> void:
	move_input = value


func set_camera_input(value: Vector2) -> void:
	camera_input = value


# ==========================
# CLEAR CONTROLADO
# ==========================

func clear_move() -> void:
	move_input = Vector2.ZERO
	move_touch_id = -1


func clear_camera() -> void:
	camera_input = Vector2.ZERO
	camera_touch_id = -1


func reset() -> void:
	clear_move()
	clear_camera()