extends RefCounted
class_name PlayerState

enum State {
	IDLE,
	WALK,
	RUN,
	SPRINT,
	CROUCH,
	PRONE,
	JUMP,
	FALL,
	ROLL,
	ATTACK,
	BLOCK,
	INTERACT,
	DEAD
	}
