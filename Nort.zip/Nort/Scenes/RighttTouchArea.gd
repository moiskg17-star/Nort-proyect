extends Control

var dragging := false
var last_pos := Vector2.ZERO

func _input(event):

	var screen_width = get_viewport().size.x

	if event is InputEventScreenTouch:

		if event.pressed and event.position.x > screen_width * 0.5:
			dragging = true
			last_pos = event.position

		elif not event.pressed:
			dragging = false
			InputManager.set_camera_input(Vector2.ZERO)

	elif event is InputEventScreenDrag and dragging:
		var delta = event.position - last_pos
		last_pos = event.position

		InputManager.set_camera_input(delta)
