extends Control

@export var radius := 120.0
@export var deadzone := 25.0

# 🔥 curva de stick (más alto = más precisión en centro)
@export var response_curve := 1.6

# 🔥 zona muerta inteligente
@export var snap_threshold := 0.15

@onready var base := $Base
@onready var knob := $Knob

var finger_id := -1

var target_input := Vector2.ZERO
var smooth_input := Vector2.ZERO

var center := Vector2.ZERO


func _ready():
	center = base.size * 0.5
	knob.position = center


func _gui_input(event):

	if event is InputEventScreenTouch:

		if event.pressed and base.get_global_rect().has_point(event.position):
			finger_id = event.index

		elif event.index == finger_id:
			finger_id = -1
			target_input = Vector2.ZERO


	elif event is InputEventScreenDrag:

		if event.index != finger_id:
			return

		var local = event.position - base.get_global_position() - center
		var dist = local.length()

		if dist < deadzone:
			target_input = Vector2.ZERO
			return

		var dir = local.normalized()

		var strength = clamp((dist - deadzone) / (radius - deadzone), 0.0, 1.0)

		# 🔥 curva no lineal tipo stick real
		strength = pow(strength, response_curve)

		var result = dir * strength

		# 🔥 snap central inteligente
		if result.length() < snap_threshold:
			target_input = Vector2.ZERO
		else:
			target_input = result


func _process(delta):

	# suavizado leve (no elimina responsividad)
	smooth_input = smooth_input.lerp(target_input, 14.0 * delta)

	InputManager.set_move_input(smooth_input)

	knob.position = center + smooth_input * radius
