extends Node
class_name PlayerStateMachine

signal state_changed(previous_state, new_state)

var current_state: PlayerState.State = PlayerState.State.IDLE


func get_state() -> PlayerState.State:
		return current_state
		
		
func change_state(new_state: PlayerState.State) -> void:
			
	if current_state == new_state:
		return
							
		var previous := current_state
		current_state = new_state
									
		state_changed.emit(previous, current_state)
										
										
func is_state(state: PlayerState.State) -> bool:
		return current_state == state
